# AttackPilot 前端

## 启动

请先启动后端，再执行：

```powershell
npm ci
npm run dev
```

浏览器打开 `http://localhost:5173`。

前端默认连接 `http://localhost:8000`，通常不需要修改配置。
