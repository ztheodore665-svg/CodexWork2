本压缩包为 AttackPilot 竞赛提交版源代码。为满足 100MB 限制，未包含 backend/compiler 下的全量 solc 二进制、backend/misc/SignItem.csv 和 backend/misc/model.pth；提交前请确认评审是否需要这些可再生成或可按需获取的材料。settings.py 中的接口凭据已用占位符脱敏。
